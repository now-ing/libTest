#ifndef __FUN_H__
#define __FUN_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <stdio.h>

int add(int x, int y);

void strprint(char *s);

#ifdef __cplusplus
}
#endif

#endif
